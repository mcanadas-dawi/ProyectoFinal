

<?php $__env->startSection('title', 'Mis Jugadores'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="text-2xl font-bold mb-4">Mis Jugadores</h1>
    <a href="<?php echo e(route('players.create')); ?>" class="bg-green-500 text-white px-4 py-2 rounded">Nuevo Jugador</a>

    <table class="w-full mt-4 border-collapse border border-gray-300">
        <thead>
            <tr class="bg-gray-200">
                <th class="border p-2">Nombre</th>
                <th class="border p-2">Dorsal</th>
                <th class="border p-2">Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="border p-2"><?php echo e($player->nombre); ?> <?php echo e($player->apellido); ?></td>
                    <td class="border p-2"><?php echo e($player->dorsal); ?></td>
                    <td class="border p-2">
                        <a href="<?php echo e(route('players.edit', $player)); ?>" class="bg-yellow-500 text-white px-3 py-1 rounded">Editar</a>
                        <form action="<?php echo e(route('players.destroy', $player)); ?>" method="POST" class="inline">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="bg-red-500 text-white px-3 py-1 rounded">Eliminar</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Marc\Desktop\ProyectoFinal\ProyectoFinal\TeamManagerPro\resources\views/players/index.blade.php ENDPATH**/ ?>