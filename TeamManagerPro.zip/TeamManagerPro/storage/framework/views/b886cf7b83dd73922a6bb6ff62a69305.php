

<?php $__env->startSection('title', 'Editar Plantilla'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="text-2xl font-bold mb-4">Editar Plantilla</h1>
    <form action="<?php echo e(route('teams.update', $team)); ?>" method="POST" class="bg-white p-4 shadow rounded">
        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>

        <label class="block">Nombre:</label>
        <input type="text" name="nombre" class="border p-2 w-full" value="<?php echo e($team->nombre); ?>" required>

        <label class="block mt-2">Modalidad:</label>
        <select name="modalidad" class="border p-2 w-full">
            <option value="F5" <?php echo e($team->modalidad == 'F5' ? 'selected' : ''); ?>>Fútbol 5</option>
            <option value="F7" <?php echo e($team->modalidad == 'F7' ? 'selected' : ''); ?>>Fútbol 7</option>
            <option value="F8" <?php echo e($team->modalidad == 'F8' ? 'selected' : ''); ?>>Fútbol 8</option>
            <option value="F11" <?php echo e($team->modalidad == 'F11' ? 'selected' : ''); ?>>Fútbol 11</option>
        </select>

        <button type="submit" class="mt-4 bg-green-500 text-black px-4 py-2 rounded">Guardar</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Marc\Desktop\ProyectoFinal\ProyectoFinal\TeamManagerPro\resources\views/teams/edit.blade.php ENDPATH**/ ?>