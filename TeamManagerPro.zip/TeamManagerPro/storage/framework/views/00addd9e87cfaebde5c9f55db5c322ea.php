

<?php $__env->startSection('title', 'Nuevo Partido'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="text-2xl font-bold mb-4">Nuevo Partido</h1>
    <form action="<?php echo e(route('matches.store')); ?>" method="POST" class="bg-white p-4 shadow rounded">
        <?php echo csrf_field(); ?>
        <label class="block">Selecciona tu equipo:</label>
        <select name="team_id" class="border p-2 w-full">
            <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($team->id); ?>"><?php echo e($team->nombre); ?> (<?php echo e($team->modalidad); ?>)</option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <label class="block mt-2">Número de Jornada:</label>
        <input type="number" name="numero_jornada" class="border p-2 w-full" required>

        <label class="block mt-2">Equipo Rival:</label>
        <input type="text" name="equipo_rival" class="border p-2 w-full" required>

        <label class="block mt-2">Fecha del Partido:</label>
        <input type="date" name="fecha_partido" class="border p-2 w-full" required>

        <button type="submit" class="mt-4 bg-green-500 text-white px-4 py-2 rounded">Guardar</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Marc\Desktop\ProyectoFinal\ProyectoFinal\TeamManagerPro\resources\views/matches/create.blade.php ENDPATH**/ ?>