

<?php $__env->startSection('title', 'Nueva Plantilla'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="text-2xl font-bold mb-4">Nueva Plantilla</h1>
    <form action="<?php echo e(route('teams.store')); ?>" method="POST" class="bg-white p-4 shadow rounded">
        <?php echo csrf_field(); ?>
        <label class="block">Nombre:</label>
        <input type="text" name="nombre" class="border p-2 w-full" required>

        <label class="block mt-2">Modalidad:</label>
        <select name="modalidad" class="border p-2 w-full">
            <option value="F5">Fútbol 5</option>
            <option value="F7">Fútbol 7</option>
            <option value="F8">Fútbol 8</option>
            <option value="F11">Fútbol 11</option>
        </select>

        <button type="submit" class="mt-4 bg-green-500 text-black px-4 py-2 rounded">Guardar</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Marc\Desktop\ProyectoFinal\ProyectoFinal\TeamManagerPro\resources\views/teams/create.blade.php ENDPATH**/ ?>