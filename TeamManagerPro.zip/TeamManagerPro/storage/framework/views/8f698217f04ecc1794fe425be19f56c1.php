

<?php $__env->startSection('title', 'Mis Plantillas'); ?>

<?php $__env->startSection('content'); ?>
    <div class="max-w-4xl mx-auto">
        
        <h1 class="text-6xl font-extrabold text-gray-800 mb-6 text-center ">⚽ Mis Plantillas</h1>
        <div class="mb-4">
            <a href="<?php echo e(route('teams.create')); ?>" class="flex items-center text-green-600 font-semibold px-4 py-2 rounded-lg hover:text-green-700 transition">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4" />
                </svg>
                Nueva Plantilla
            </a>
        </div>

        <div class="bg-white shadow-md rounded-lg overflow-hidden">
            <table class="w-full border-collapse">
                <thead>
                    <tr class="bg-gradient-to-r from-blue-500 to-blue-700 text-white">
                        <th class="p-3 text-left">Nombre</th>
                        <th class="p-3 text-left">Modalidad</th>
                        <th class="p-3 text-center">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="border-b hover:bg-gray-100 transition">
                            <td class="p-4 text-gray-800 font-medium"><?php echo e($team->nombre); ?></td>
                            <td class="p-4 text-gray-600"><?php echo e($team->modalidad); ?></td>
                            <td class="p-4 flex justify-center space-x-2">
                                <a href="<?php echo e(route('teams.edit', $team)); ?>" class="bg-yellow-500 text-white px-4 py-2 rounded-lg shadow-md hover:bg-yellow-600 transform hover:scale-105 transition">
                                    ✏️ Editar
                                </a>
                                <form action="<?php echo e(route('teams.destroy', $team)); ?>" method="POST" onsubmit="return confirm('¿Seguro que deseas eliminar esta plantilla?');">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="bg-red-500 text-white px-4 py-2 rounded-lg shadow-md hover:bg-red-600 transform hover:scale-105 transition">
                                        🗑️ Eliminar
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Marc\Desktop\ProyectoFinal\ProyectoFinal\TeamManagerPro\resources\views/teams/index.blade.php ENDPATH**/ ?>