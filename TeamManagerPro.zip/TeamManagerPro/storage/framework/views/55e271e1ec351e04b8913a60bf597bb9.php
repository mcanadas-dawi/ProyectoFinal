<?php $__env->startSection('content'); ?>
<div class="container mx-auto p-6">
    <h2 class="text-2xl font-semibold text-gray-900 mb-4">Valorar Jugadores del Partido</h2>

    <form action="<?php echo e(route('matches.saveRatings', $match->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php $__currentLoopData = $match->players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="mb-4">
                <label class="block text-gray-700 font-semibold">
                    <?php echo e($player->nombre); ?> <?php echo e($player->apellido); ?> (Dorsal: <?php echo e($player->dorsal); ?>)
                </label>
                <input type="number" name="ratings[<?php echo e($player->id); ?>]" min="1" max="10" required 
                       class="w-16 p-2 border rounded text-center">
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <button type="submit" class="bg-green-500 text-white px-4 py-2 rounded-lg">Guardar Valoraciones</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Marc\Desktop\ProyectoFinal\ProyectoFinal\TeamManagerPro\resources\views/matches/rate_players.blade.php ENDPATH**/ ?>