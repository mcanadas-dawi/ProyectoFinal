<!-- resources/views/dashboard/team_show.blade.php -->


<?php $__env->startSection('content'); ?>
<div class="container mx-auto p-6">
    <h1 class="text-3xl font-bold text-gray-800 mb-6"><?php echo e($team->nombre); ?> (<?php echo e(strtoupper($team->modalidad)); ?>)</h1>

    <!-- Botón para eliminar equipo -->
    <form action="<?php echo e(route('teams.destroy', $team->id)); ?>" method="POST" onsubmit="return confirm('¿Estás seguro de que deseas eliminar este equipo? Esta acción no se puede deshacer.')" class="mb-4 text-right">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button type="submit" class="bg-red-500 text-white px-4 py-2 rounded-lg">Eliminar Equipo</button>
    </form>

    <!-- AÑADIR JUGADORES DE OTRAS PLANTILLAS-->
    <div class="bg-purple-200 shadow-lg rounded-lg p-6 mb-6">
        <h2 class="text-2xl font-semibold text-gray-900 mb-4 text-center">Añadir Jugador Existente</h2>
        <form action="<?php echo e(route('players.addToTeam')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="team_id" value="<?php echo e($team->id); ?>">
            <div class="mb-4">
                <label for="player_id" class="block text-gray-700 font-semibold">Seleccionar jugador procedente de otra plantilla:</label>
                <select name="player_id" id="player_id" class="w-full p-2 border rounded bg-white text-center" required>
                    <option value=""> Seleccionar </option>
                    <?php $__currentLoopData = $allPlayers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(!$team->players->contains($player->id)): ?> <!-- Evita mostrar jugadores ya en la plantilla -->
                    <option value="<?php echo e($player->id); ?>"><?php echo e($player->nombre); ?> <?php echo e($player->apellido); ?> (DNI: <?php echo e($player->dni); ?>)</option>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <button type="submit" class="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700">Añadir Jugador</button>
        </form>
    </div>

    <!-- Sección de Jugadores -->
    <div class="bg-blue-200 shadow-lg rounded-lg p-6 mb-6">
    <div class="flex items-center justify-center mb-4">
        <h2 class="text-2xl font-semibold text-gray-900 flex-grow text-center">Jugadores</h2>
        <button onclick="openAddPlayerModal()" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">
            Añadir Jugador
        </button>
    </div>
        <table class="w-full text-center border-collapse">
            <thead class="bg-blue-300 text-gray-900">
                <tr class="border-b">
                    <th class="p-2">Nombre</th>
                    <th class="p-2">Apellido</th>
                    <th class="p-2">DNI</th>
                    <th class="p-2">Dorsal</th>
                    <th class="p-2">Fecha Nac.</th>
                    <th class="p-2">Posición</th>
                    <th class="p-2">Perfil</th>
                    <th class="p-2">Minutos Jugados</th>
                    <th class="p-2">Goles</th>
                    <th class="p-2">Asistencias</th>
                    <th class="p-2">Titular</th>
                    <th class="p-2">Suplente</th>
                    <th class="p-2">Valoración</th>
                    <th class="p-2">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $team->players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="border-b bg-blue-100" id="player-row-<?php echo e($player->id); ?>">
                    <td class="p-2"><?php echo e($player->nombre); ?></td>
                    <td class="p-2"><?php echo e($player->apellido); ?></td>
                    <td class="p-2"><?php echo e($player->dni); ?></td>
                    <td class="p-2"><?php echo e($player->dorsal); ?></td>
                    <td class="p-2"><?php echo e($player->fecha_nacimiento); ?></td>
                    <td class="p-2">
                        <span id="pos-<?php echo e($player->id); ?>"><?php echo e($player->posicion); ?></span>
                        <select name="posicion" class="hidden w-full p-1 border rounded" id="edit-pos-<?php echo e($player->id); ?>">
                            <option value="Portero">Portero</option>
                            <option value="Defensa">Defensa</option>
                            <option value="Centrocampista">Centrocampista</option>
                            <option value="Delantero">Delantero</option>
                        </select>
                    </td>
                    <td class="p-2">
                        <span id="perfil-<?php echo e($player->id); ?>"><?php echo e($player->perfil); ?></span>
                        <select name="perfil" class="hidden w-full p-1 border rounded" id="edit-perfil-<?php echo e($player->id); ?>">
                            <option value="Diestro">Diestro</option>
                            <option value="Zurdo">Zurdo</option>
                        </select>
                    </td>
                    <td class="p-2">
                        <span id="min-<?php echo e($player->id); ?>"><?php echo e($player->minutos_jugados); ?></span>
                        <input type="number" name="minutos_jugados" class="hidden w-16 p-1 border rounded" id="edit-min-<?php echo e($player->id); ?>">
                    </td>
                    <td class="p-2">
                        <span id="goles-<?php echo e($player->id); ?>"><?php echo e($player->goles); ?></span>
                        <input type="number" name="goles" class="hidden w-16 p-1 border rounded" id="edit-goles-<?php echo e($player->id); ?>">
                    </td>
                    <td class="p-2">
                        <span id="asistencias-<?php echo e($player->id); ?>"><?php echo e($player->asistencias); ?></span>
                        <input type="number" name="asistencias" class="hidden w-16 p-1 border rounded" id="edit-asistencias-<?php echo e($player->id); ?>">
                    </td>
                    <td class="p-2">
                        <span id="titular-<?php echo e($player->id); ?>"><?php echo e($player->titular); ?></span>
                        <input type="number" name="titular" class="hidden w-16 p-1 border rounded" id="edit-titular-<?php echo e($player->id); ?>">
                    </td>
                    <td class="p-2">
                        <span id="suplente-<?php echo e($player->id); ?>"><?php echo e($player->suplente); ?></span>
                        <input type="number" name="suplente" class="hidden w-16 p-1 border rounded" id="edit-suplente-<?php echo e($player->id); ?>">
                    </td>
                    <td class="p-2">
                        <span id="valoracion-<?php echo e($player->id); ?>"><?php echo e($player->valoracion); ?></span>
                        <input type="number" name="valoracion" class="hidden w-16 p-1 border rounded" id="edit-valoracion-<?php echo e($player->id); ?>">
                    </td>
                    <td class="p-2 text-center">
                        <button onclick="editPlayer('<?php echo e($player->id); ?>')" id="edit-btn-<?php echo e($player->id); ?>" class="bg-yellow-500 text-white px-3 py-1 rounded">Editar</button>
                        <button onclick="savePlayer('<?php echo e($player->id); ?>')" id="save-btn-<?php echo e($player->id); ?>" class="hidden bg-green-500 text-white px-3 py-1 rounded">Guardar</button>
                        <form action="<?php echo e(route('players.destroy', $player->id)); ?>" method="POST" onsubmit="return confirm('¿Estás seguro de que deseas eliminar a este jugador? Esta acción no se puede deshacer.')" class="inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="bg-red-500 text-white px-3 py-1 rounded">Eliminar</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

<!-- Sección de Partidos -->
<div class="bg-green-200 shadow-lg rounded-lg p-6 mb-6">
    <div class="flex items-center justify-center mb-4">
        <h2 class="text-2xl font-semibold text-gray-900 flex-grow text-center">Partidos</h2>
        <button onclick="openAddMatchModal()" class="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700">
            Añadir Partido
        </button>
    </div>

    <table class="w-full text-center border-collapse bg-white rounded-lg">
        <thead class="bg-green-300 text-gray-900">
            <tr class="border-b">
                <th class="p-2">Jornada</th>
                <th class="p-2">Equipo Rival</th>
                <th class="p-2">Fecha</th>
                <th class="p-2">Goles a Favor</th>
                <th class="p-2">Goles en Contra</th>
                <th class="p-2">Alineación</th>
                <th class="p-2">Convocatoria</th>
                <th class="p-2">Acciones</th>
            </tr>
        </thead>
        <tbody class="text-gray-800">
    <?php $__currentLoopData = $team->matches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr class="border-b bg-green-100">
                <td class="p-2 text-center"><?php echo e($match->numero_jornada); ?></td>
                <td class="p-2 text-center"><?php echo e($match->equipo_rival); ?></td>
                
                <td class="p-2 text-center">
            <span id="min-fecha-<?php echo e($match->id); ?>"><?php echo e($match->fecha_partido); ?></span>
            <input type="date" name="fecha_partido" class="hidden w-16 p-1 border rounded" id="edit-fecha-<?php echo e($match->id); ?>">
        </td>

        <td class="p-2 text-center">
            <span id="min-goles-favor-<?php echo e($match->id); ?>"><?php echo e($match->goles_a_favor); ?></span>
            <input type="number" name="goles_a_favor" class="hidden w-16 p-1 border rounded" id="edit-goles-favor-<?php echo e($match->id); ?>">
        </td>

        <td class="p-2 text-center">
            <span id="min-goles-contra-<?php echo e($match->id); ?>"><?php echo e($match->goles_en_contra); ?></span>
            <input type="number" name="goles_en_contra" class="hidden w-16 p-1 border rounded" id="edit-goles-contra-<?php echo e($match->id); ?>">
        </td>

                <td class="p-2 text-center">
                    <button onclick="openConvocatoriaModal('<?php echo e($match->id); ?>')" class="bg-blue-500 text-white px-3 py-1 rounded">
                        Convocatoria
                    </button>
                </td>
                <td class="p-2 text-center">
                    <button onclick="openAlineador('<?php echo e($match->id); ?>')" class="bg-indigo-500 text-white px-3 py-1 rounded">
                        Alineador
                    </button>
                </td>
                <td class="p-2 text-center">
                    <a href="<?php echo e(route('matches.ratePlayers', $match->id)); ?>" class="bg-orange-400 text-white px-3 py-1 rounded block mb-2">
                    Valorar Jugadores 
                    </a>

                    <button onclick="editMatch('<?php echo e($match->id); ?>')" id="edit-btn-match-<?php echo e($match->id); ?>" class="bg-yellow-500 text-white px-3 py-1 rounded">Editar</button>
                    <button onclick="saveMatch('<?php echo e($match->id); ?>')" id="save-btn-match-<?php echo e($match->id); ?>" class="hidden bg-green-500 text-white px-3 py-1 rounded">Guardar</button>
                    <form action="<?php echo e(route('matches.destroy', $match->id)); ?>" method="POST" onsubmit="return confirm('¿Estás seguro de que deseas eliminar este partido? Esta acción no se puede deshacer.')" class="inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="bg-red-500 text-white px-3 py-1 rounded">Eliminar</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<!-- Modal para Añadir Jugador -->
<div id="addPlayerModal" class="hidden fixed inset-0 bg-gray-900 bg-opacity-50 flex justify-center items-center">
    <div class="bg-white rounded-lg p-6 w-1/3">
        <h2 class="text-xl font-semibold text-gray-800 mb-4">Añadir Jugador</h2>
        <form action="<?php echo e(route('players.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="team_id" value="<?php echo e($team->id); ?>">

            <input type="text" name="nombre" placeholder="Nombre" class="w-full p-2 border rounded mb-2" required>
            <input type="text" name="apellido" placeholder="Apellido" class="w-full p-2 border rounded mb-2" required>
            <input type="text" name="dni" placeholder="DNI" class="w-full p-2 border rounded mb-2" required>
            <input type="number" name="dorsal" placeholder="Dorsal" class="w-full p-2 border rounded mb-2" required>

            <label class="block text-gray-700 font-semibold">Fecha de nacimiento</label>
            <input type="date" name="fecha_nacimiento" class="w-full p-2 border rounded mb-2" required>

            <label class="block text-gray-700 font-semibold">Posición</label>
            <select name="posicion" required class="w-full p-2 border rounded-lg mb-2">
                <option value="Portero">Portero</option>
                <option value="Defensa">Defensa</option>
                <option value="Centrocampista">Centrocampista</option>
                <option value="Delantero">Delantero</option>
            </select>

            <label class="block text-gray-700 font-semibold">Perfil</label>
            <select name="perfil" required class="w-full p-2 border rounded-lg mb-2">
                <option value="Diestro">Diestro</option>
                <option value="Zurdo">Zurdo</option>
            </select>

            <div class="flex justify-end space-x-2 mt-4">
                <button type="submit" class="bg-green-500 text-white px-4 py-2 rounded-lg">Guardar</button>
                <button type="button" onclick="closeAddPlayerModal()" class="bg-gray-500 text-white px-4 py-2 rounded-lg">Cancelar</button>
            </div>
        </form>
    </div>
</div>

<!-- Modal para Añadir Partido -->
<div id="addMatchModal" class="hidden fixed inset-0 bg-gray-900 bg-opacity-50 flex justify-center items-center">
    <div class="bg-white rounded-lg p-6 w-1/3">
        <h2 class="text-xl font-semibold text-gray-800 mb-4">Añadir Partido</h2>
        <form action="<?php echo e(route('matches.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="team_id" value="<?php echo e($team->id); ?>">
            <input type="number" name="numero_jornada" placeholder="Jornada" class="w-full p-2 border rounded mb-2" required>
            <input type="text" name="equipo_rival" placeholder="Equipo Rival" class="w-full p-2 border rounded mb-2" required>
            <input type="date" name="fecha_partido" class="w-full p-2 border rounded mb-2" required>
            <button type="submit" class="bg-green-500 text-white px-4 py-2 rounded-lg">Guardar</button>
            <button type="button" onclick="closeAddMatchModal()" class="bg-gray-500 text-white px-4 py-2 rounded-lg">Cancelar</button>
        </form>
    </div>
</div>

<!-- Modal del Alineador -->
<div id="alineadorModal" class="hidden fixed inset-0 bg-gray-900 bg-opacity-50 flex justify-center items-center">
    <div class="bg-white rounded-lg p-6 w-3/4">
        <h2 class="text-2xl font-semibold text-gray-800 mb-4 text-center">Alineador Táctico</h2>

        <label class="block text-gray-700 font-semibold">Seleccionar Formación:</label>
            <select id="formation-selector" class="w-full p-2 border rounded-lg mb-4" onchange="updateFormation()">
                <option value="">Seleccionar...</option>
                <option value="libre">Libre</option>
                <?php if($team->modalidad == 'F5'): ?>
                    <option value="1-1-2-1">1-1-2-1</option>
                    <option value="1-2-1-1">1-2-1-1</option>
                <?php elseif($team->modalidad == 'F7'): ?>
                    <option value="1-3-2-1">1-3-2-1</option>
                    <option value="1-2-3-1">1-2-3-1</option>
                <?php elseif($team->modalidad == 'F8'): ?>
                    <option value="1-3-3-1">1-3-3-1</option>
                    <option value="1-2-4-1">1-2-4-1</option>
                <?php elseif($team->modalidad == 'F11'): ?>
                    <option value="1-4-4-2">1-4-4-2</option>
                    <option value="1-4-3-3">1-4-3-3</option>
                    <option value="1-5-3-2">1-5-3-2</option>
                <?php endif; ?>
            </select>


        <!-- Campo de Fútbol -->
        <div id="field-container" class="relative bg-green-500 h-96 flex justify-center items-center">
            <img src="<?php echo e(asset('Imagenes/campo_futbol.jpg')); ?>" alt="Campo de Fútbol" class="w-full h-full object-cover">
            <div id="player-spots" class="absolute inset-0 flex flex-wrap justify-center items-center">
                <!-- Aquí se inyectarán los jugadores según la formación -->
            </div>
        </div>

        <!-- Lista de suplentes -->
        <h3 class="text-xl font-semibold text-gray-800 mt-4">Suplentes</h3>
        <div id="suplentes-list" class="max-h-40 overflow-y-auto bg-gray-100 p-2 rounded-lg">
            <table class="w-full">
                <thead>
                    <tr class="text-gray-700">
                        <th class="p-2">Nombre</th>
                        <th class="p-2">Apellido</th>
                        <th class="p-2">Dorsal</th>
                        <th class="p-2">Posición</th>
                        <th class="p-2">Perfil</th>
                    </tr>
                </thead>
                <tbody id="suplentes-body">
                    <!-- Aquí se inyectarán los suplentes -->
                </tbody>
            </table>
        </div>

        <div class="mt-4 flex justify-between">
            <button onclick="saveAlineacion()" class="bg-green-500 text-white px-4 py-2 rounded-lg">
                Guardar Alineación
            </button>
            <button onclick="closeAlineador()" class="bg-gray-500 text-white px-4 py-2 rounded-lg">
                Cerrar
            </button>
        </div>
    </div>
</div>


<!-- Modal para Convocatoria -->
<div id="convocatoriaModal" class="hidden fixed inset-0 bg-gray-900 bg-opacity-50 flex justify-center items-center">
    <div class="bg-white rounded-lg p-6 w-1/3">
        <h2 class="text-xl font-semibold text-gray-800 mb-4 text-center">Seleccionar Jugadores Convocados</h2>
        <form id="convocatoriaForm">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="match_id" value="<?php echo e($match->id); ?>">

            <!-- Lista de jugadores con checkboxes -->
            <div class="max-h-60 overflow-y-auto">
                <?php $__currentLoopData = $team->players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="flex items-center mb-2">
                    <input type="checkbox" id="player-<?php echo e($player->id); ?>" name="convocados[]"
                        value="<?php echo e($player->id); ?>" class="mr-2"
                        <?php echo e(in_array($player->id, $convocados) ? 'checked' : ''); ?>>
                    <label for="player-<?php echo e($player->id); ?>"><?php echo e($player->nombre); ?> <?php echo e($player->apellido); ?></label>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="mt-4 flex justify-between">
                <button type="button" onclick="saveConvocatoria()" class="bg-green-500 text-white px-4 py-2 rounded-lg">
                    Guardar Convocatoria
                </button>
                <button type="button" onclick="closeConvocatoriaModal()" class="bg-gray-500 text-white px-4 py-2 rounded-lg">
                    Cancelar
                </button>
            </div>
        </form>
    </div>
</div>

<script>
    function editPlayer(id) {
        document.getElementById('edit-btn-' + id).classList.add('hidden');
        document.getElementById('save-btn-' + id).classList.remove('hidden');

        document.getElementById('pos-' + id).classList.add('hidden');
        document.getElementById('edit-pos-' + id).classList.remove('hidden');

        document.getElementById('perfil-' + id).classList.add('hidden');
        document.getElementById('edit-perfil-' + id).classList.remove('hidden');

        document.getElementById('min-' + id).classList.add('hidden');
        document.getElementById('edit-min-' + id).classList.remove('hidden');

        document.getElementById('goles-' + id).classList.add('hidden');
        document.getElementById('edit-goles-' + id).classList.remove('hidden');

        document.getElementById('asistencias-' + id).classList.add('hidden');
        document.getElementById('edit-asistencias-' + id).classList.remove('hidden');

        document.getElementById('titular-' + id).classList.add('hidden');
        document.getElementById('edit-titular-' + id).classList.remove('hidden');

        document.getElementById('suplente-' + id).classList.add('hidden');
        document.getElementById('edit-suplente-' + id).classList.remove('hidden');

        document.getElementById('valoracion-' + id).classList.add('hidden');
        document.getElementById('edit-valoracion-' + id).classList.remove('hidden');

    }

    function savePlayer(id) {
        let csrfToken = document.querySelector('meta[name="csrf-token"]').content;

        let posicion = document.getElementById('edit-pos-' + id).value;
        let perfil = document.getElementById('edit-perfil-' + id).value;
        let minutos = document.getElementById('edit-min-' + id).value;
        let goles = document.getElementById('edit-goles-' + id).value;
        let asistencias = document.getElementById('edit-asistencias-' + id).value;
        let titular = document.getElementById('edit-titular-' + id).value;
        let suplente = document.getElementById('edit-suplente-' + id).value;
        let valoracion = document.getElementById('edit-valoracion-' + id).value;
        let form = document.createElement('form');
        form.method = 'POST';
        form.action = `/players/${id}`;

        form.appendChild(createHiddenInput('_token', csrfToken));
        form.appendChild(createHiddenInput('_method', 'PATCH'));
        form.appendChild(createHiddenInput('posicion', posicion));
        form.appendChild(createHiddenInput('perfil', perfil));
        form.appendChild(createHiddenInput('minutos_jugados', minutos));
        form.appendChild(createHiddenInput('goles', goles));
        form.appendChild(createHiddenInput('asistencias', asistencias));
        form.appendChild(createHiddenInput('titular', titular));
        form.appendChild(createHiddenInput('suplente', suplente));
        form.appendChild(createHiddenInput('valoracion', valoracion));

        document.body.appendChild(form);
        form.submit();
    }


    function createHiddenInput(name, value) {
        let input = document.createElement('input');
        input.type = 'hidden';
        input.name = name;
        input.value = value;
        return input;
    }

    function editMatch(id) {
    // Ocultar el botón "Editar" y mostrar el botón "Guardar"
    document.getElementById('edit-btn-match-' + id).classList.add('hidden');
    document.getElementById('save-btn-match-' + id).classList.remove('hidden');

    // Mostrar inputs y ocultar spans
    document.getElementById('min-fecha-' + id).classList.add('hidden');
    document.getElementById('edit-fecha-' + id).classList.remove('hidden');

    document.getElementById('min-goles-favor-' + id).classList.add('hidden');
    document.getElementById('edit-goles-favor-' + id).classList.remove('hidden');

    document.getElementById('min-goles-contra-' + id).classList.add('hidden');
    document.getElementById('edit-goles-contra-' + id).classList.remove('hidden');

    // Asegurar que los campos sean editables
    document.getElementById('edit-fecha-' + id).removeAttribute('disabled');
    document.getElementById('edit-goles-favor-' + id).removeAttribute('disabled');
    document.getElementById('edit-goles-contra-' + id).removeAttribute('disabled');
}

    function saveMatch(id) {
        let csrfToken = document.querySelector('meta[name="csrf-token"]').content;

        let fecha = document.getElementById('edit-fecha-' + id).value;
        let golesFavor = document.getElementById('edit-goles-favor-' + id).value;
        let golesContra = document.getElementById('edit-goles-contra-' + id).value;

        let form = document.createElement('form');
        form.method = 'POST';
        form.action = `/matches/${id}`;

        form.appendChild(createHiddenInput('_token', csrfToken));
        form.appendChild(createHiddenInput('_method', 'PATCH'));
        form.appendChild(createHiddenInput('fecha_partido', fecha));
        form.appendChild(createHiddenInput('goles_a_favor', golesFavor));
        form.appendChild(createHiddenInput('goles_en_contra', golesContra));

        document.body.appendChild(form);
        form.submit();
    }

    function openAlineador(matchId) {
        document.getElementById('alineadorModal').classList.remove('hidden');
    }

    function closeAlineador() {
        document.getElementById('alineadorModal').classList.add('hidden');
    }
//CONVOCATORIA
    function openConvocatoriaModal(matchId) {
        document.getElementById('convocatoriaModal').classList.remove('hidden');
    }
    function closeConvocatoriaModal(matchId) {
        document.getElementById('convocatoriaModal').classList.add('hidden');
    }
    function saveConvocatoria() {
    let csrfToken = document.querySelector('meta[name="csrf-token"]').content;
    let matchId = document.querySelector('input[name="match_id"]').value;
    
    // Obtener jugadores seleccionados
    let seleccionados = [];
    document.querySelectorAll('input[name="convocados[]"]:checked').forEach((checkbox) => {
        seleccionados.push(checkbox.value);
    });

    fetch(`/matches/${matchId}/convocatoria`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': csrfToken
        },
        body: JSON.stringify({ convocados: seleccionados })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('Convocatoria guardada correctamente');
            closeConvocatoriaModal();
        }
    })
    .catch(error => console.error('Error:', error));
}

//PLAYER MODAL
    function openAddPlayerModal() {
        document.getElementById('addPlayerModal').classList.remove('hidden');
    }

    function closeAddPlayerModal() {
        document.getElementById('addPlayerModal').classList.add('hidden');
    }

    function openAddMatchModal() {
        document.getElementById('addMatchModal').classList.remove('hidden');
    }

    function closeAddMatchModal() {
        document.getElementById('addMatchModal').classList.add('hidden');
    }


    //ALINEADOR
    document.addEventListener('DOMContentLoaded', function () {
    const formationSelector = document.getElementById('formation-selector');
    const fieldContainer = document.getElementById('player-spots');
    const saveFormationButton = document.getElementById('save-formation');
    const suplentesBody = document.getElementById('suplentes-body');

    const formaciones = {
        "1-1-2-1": ["Portero", "Defensa", "Centrocampista", "Centrocampista", "Delantero"],
        "1-2-1-1": ["Portero", "Defensa", "Defensa", "Centrocampista", "Delantero"],
        "1-3-2-1": ["Portero", "Defensa", "Defensa", "Defensa", "Centrocampista", "Centrocampista", "Delantero"],
        "1-2-3-1": ["Portero", "Defensa", "Defensa", "Centrocampista", "Centrocampista", "Centrocampista", "Delantero"],
        "1-3-3-1": ["Portero", "Defensa", "Defensa", "Defensa", "Centrocampista", "Centrocampista", "Centrocampista", "Delantero"],
        "1-2-4-1": ["Portero", "Defensa", "Defensa", "Centrocampista", "Centrocampista", "Centrocampista", "Centrocampista", "Delantero"],
        "1-4-4-2": ["Portero", "Defensa", "Defensa", "Defensa", "Defensa", "Centrocampista", "Centrocampista", "Delantero", "Delantero"],
        "1-4-3-3": ["Portero", "Defensa", "Defensa", "Defensa", "Defensa", "Centrocampista", "Centrocampista", "Centrocampista", "Delantero", "Delantero", "Delantero"],
        "1-5-3-2": ["Portero", "Defensa", "Defensa", "Defensa", "Defensa", "Defensa", "Centrocampista", "Centrocampista", "Centrocampista", "Delantero", "Delantero"]
    };

    function updateFormation() {
        let formation = document.getElementById('formation-selector').value;
        let fieldContainer = document.getElementById('player-spots');
        fieldContainer.innerHTML = '';

        let convocados = JSON.parse('<?php echo json_encode($convocados[$match->id] ?? []); ?>');
        let selectedPlayers = new Set();

        if (formation === "libre") {
            createFreeFormation(fieldContainer, convocados);
            return;
        }

        if (!formation || !formaciones[formation]) return;

        formaciones[formation].forEach((posicion, index) => {
            let select = document.createElement('select');
            select.classList.add("absolute", "border", "rounded", "p-2", "bg-white", "draggable-player");
            select.style.top = `${(index + 1) * 10}%`;
            select.style.left = `${50 - (index * 5)}%`;

            let defaultOption = document.createElement('option');
            defaultOption.value = "";
            defaultOption.text = posicion;
            select.appendChild(defaultOption);

            convocados.forEach(player => {
                let option = document.createElement('option');
                option.value = player.id;
                option.text = `${player.nombre} (${player.posicion})`;

                if (!selectedPlayers.has(player.id)) {
                    select.appendChild(option);
                }
            });

            select.addEventListener("change", function() {
                selectedPlayers.add(select.value);
                updateSuplentes(convocados, selectedPlayers);
            });

            fieldContainer.appendChild(select);
        });

        updateSuplentes(convocados, selectedPlayers);
    }

    function createFreeFormation(container, convocados) {
        container.innerHTML = "";

        for (let i = 0; i < 11; i++) {
            let div = document.createElement("div");
            div.classList.add("absolute", "w-10", "h-10", "bg-blue-500", "rounded-full", "cursor-move", "draggable-player");
            div.style.top = `${Math.random() * 80 + 10}%`;
            div.style.left = `${Math.random() * 80 + 10}%`;

            let select = document.createElement('select');
            select.classList.add("border", "rounded", "p-1", "bg-white");

            let defaultOption = document.createElement('option');
            defaultOption.value = "";
            defaultOption.text = "Seleccionar";
            select.appendChild(defaultOption);

            convocados.forEach(player => {
                let option = document.createElement('option');
                option.value = player.id;
                option.text = `${player.nombre} (${player.posicion})`;
                select.appendChild(option);
            });

            div.appendChild(select);
            container.appendChild(div);

            makeDraggable(div);
        }
    }

    function makeDraggable(element) {
        let isDragging = false;
        let offsetX, offsetY;

        element.addEventListener("mousedown", (e) => {
            isDragging = true;
            offsetX = e.clientX - element.getBoundingClientRect().left;
            offsetY = e.clientY - element.getBoundingClientRect().top;
            element.style.zIndex = "1000";
        });

        document.addEventListener("mousemove", (e) => {
            if (!isDragging) return;
            element.style.left = `${e.clientX - offsetX}px`;
            element.style.top = `${e.clientY - offsetY}px`;
        });

        document.addEventListener("mouseup", () => {
            isDragging = false;
            element.style.zIndex = "1";
        });
    }

    function updateSuplentes(convocados, titulares) {
        let suplentesBody = document.getElementById("suplentes-body");
        suplentesBody.innerHTML = "";

        convocados.forEach(player => {
            if (!titulares.has(player.id)) {
                let row = document.createElement("tr");
                row.innerHTML = `
                    <td class="p-2">${player.nombre}</td>
                    <td class="p-2">${player.apellido}</td>
                    <td class="p-2">${player.dorsal}</td>
                    <td class="p-2">${player.posicion}</td>
                    <td class="p-2">${player.perfil}</td>
                `;
                suplentesBody.appendChild(row);
            }
        });
    }

    function saveAlineacion() {
        alert("Alineación guardada correctamente.");
        closeAlineador();
    }

    function closeAlineador() {
        document.getElementById('alineadorModal').classList.add('hidden');
    }
});



</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Marc\Desktop\ProyectoFinal\ProyectoFinal\TeamManagerPro\resources\views/dashboard/team_show.blade.php ENDPATH**/ ?>